const BASEURL = "https://v6.kuramanime.run"

module.exports = BASEURL